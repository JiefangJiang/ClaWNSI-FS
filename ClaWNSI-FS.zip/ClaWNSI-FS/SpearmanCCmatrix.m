function [scc] = SpearmanCCmatrix(fuzzymatrix)

[row, column]=size(fuzzymatrix);
sccmatrix=zeros(row,row);

for i=1:row
    x=fuzzymatrix(i,:)';
    for j=1:row
        y=fuzzymatrix(j,:)';
        temp=corr(x,y,'type','Spearman');
        if (isnan(temp))
           sccmatrix(i,j)=0;
        else
           sccmatrix(i,j)=temp;
        end
    end
end
sccmatrix;
scc=zeros(1,row);
for k=1:row
     denominator=sum(abs(sccmatrix(k,:)));
     temp2=sqrt(abs(sccmatrix(k,k))/denominator);

    if (isnan(temp2))
        scc(k)=1;
    else
        scc(k)=temp2;
    end
end
scc;
end

