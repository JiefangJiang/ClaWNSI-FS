
clear all;
clc;

load('data2.mat')

delta=0.2;
beta=0.2;

[A,feature_num]=AlgorithmClaWNSI(data2,delta,beta)