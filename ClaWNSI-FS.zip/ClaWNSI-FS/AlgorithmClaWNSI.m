%%%%%%%%%%%Feature selection algorithm for ClaWNSI-FS submitted to Information Sciences
%%%%%%%%%%%Completed by Jiefang Jiang in July 12, 2023

%%%%%%%%%%%delta,beta are both parameters between 0-1 and they are set according to the specific situations
function [A,feature_num] = AlgorithmClaWNSI(train_data,delta,beta)

[row, column]=size(train_data);
F=1:(column-1);%All features 
A=[];Jointscore=[];
Ff=[];
[~, ia] = setdiff(F, A);
ComplementA=F(sort(ia));%The completement of A 

while true

    Jointscore=[];
    for i=1:length(ComplementA)
         BingjiAf=union(A,ComplementA(i));
         b=NeighborSelfInformation(train_data,DISmatrix(train_data,BingjiAf,delta));
         Jointscore(i)=b;
    end
    Jointscore;
    
    indexpre=find(Jointscore==min(Jointscore));
    if (length(indexpre)>1)
        index=indexpre(1);
    else
        index=indexpre;
    end
    index;
    f = ComplementA(index);
    Ff=[Ff,f];
    bb=NeighborSelfInformation(train_data,DISmatrix(train_data,A,delta));
    h=bb;
    
    if (h-min(Jointscore) > beta)
        A = union(A,f);
        [~, ia] = setdiff(F, A);
        ComplementA=F(sort(ia));       
    else
        break;
    end
end

A;
feature_num = length(A);

end

