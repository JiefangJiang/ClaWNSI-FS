function [value] = SUBSETJUDGE(setA,setB)
%判断B是否为A的子集
bool=ismember(setA,setB);
if (sum(bool)==length(setB))
    value=1;
else
    value=0;
end
end

