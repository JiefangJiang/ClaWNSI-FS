function [similaritymatrix]=DISmatrix(tablematrix,attributeset,delta)


[row column]=size(tablematrix);
Len=length(attributeset);

if (isempty(attributeset))
    similaritymatrix=[];
else
    for i=1:row
        for j=1:row
            DELTAPBSUMDIS=0;
            SUMDIS=0;
            for k=1:Len
                DISk=(abs(tablematrix(i,attributeset(k))-tablematrix(j,attributeset(k))))^2;%%�˴�ʹ�õ�ŷʽ���룻�����ɸ�����Ҫ�ı�Ϊ�������룻
                SUMDIS= SUMDIS + DISk;
                DISk=0;
            end
            DELTAPBSUMDIS= sqrt(SUMDIS);
            if (DELTAPBSUMDIS <=delta) 
                R_B(i,j)=1;
            else
                R_B(i,j)=0;
            end  
        end 
    end
    similaritymatrix=R_B;
end















