function [selfinformation] = NeighborSelfInformation(normalizeddata,DISmatrix)

if (isempty(DISmatrix))
    selfinformation=100;
else
   
    [Lmatrix,Lapp]=LowerappRegion(normalizeddata,DISmatrix);
    Lscc=SpearmanCCmatrix(Lmatrix);
    TotalLowerapp=Lscc*Lapp';

    [Umatrix,Uapp]=UpperappRegion(normalizeddata,DISmatrix);
    Uscc=SpearmanCCmatrix(Umatrix);
    TotalUpperapp=Uscc*Uapp';

    temp=abs(TotalLowerapp)/abs(TotalUpperapp);

    if (isnan(temp))
        selfinformation=100;
    else
        Alpha=abs(TotalLowerapp)/abs(TotalUpperapp);
        Beta=1-Alpha;
        selfinformation=-Beta*log(Alpha);
    end
end

end

