function [MatrixPOS,Jvalue] = UpperappRegion(normalizeddata,DISmatrix)

[row, column]=size(normalizeddata);
decisioninformation=normalizeddata(:,column)';
A=unique(decisioninformation);
rowposregionmatrix=numel(A);
columnposregionmatrix=row;
MatrixPOS=zeros(rowposregionmatrix,columnposregionmatrix);

if (isempty(DISmatrix))
    MatrixPOS=[];
    Jvalue=ones(1,row);
else
    for i=1:length(A)
            B= find(decisioninformation==A(i));
            Xset(i)=length(B);
            for j=1:row 
                vectora=DISmatrix(j,:);
                ClassC=find(vectora==1);
                MatrixPOS(i,j)=~isempty(intersect(B,ClassC));
            end
    end 
    
    for m=1:numel(A)
        Jvalue(m)=sum(MatrixPOS(m,:))*Xset(m)/row;        
    end
    
end

